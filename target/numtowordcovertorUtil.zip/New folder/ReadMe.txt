----------------------------------Number to Word Conversion---------------------------------------------------------------

Package contains:

Class as "NumberToWordConversionApp"

having 3 methods:

1. numToWordConversionStandaloneApp:

It is a standalone app taking input from user and deleivering the output on the console.

2. convertNumberLessThanOrHundred:

this method  converts (any number less than 101) provided to it as a parameter into words.

3. convertNumberGreaterthanHundred:

this method  converts (any number greater than 100 but less than 1000) provided to it as a parameter into words


packaged using maven...